module.exports = {
  API_KEY: "c26482859db5c94b06036b75c61ad4ec",
  BASE_URL: "https://api.openweathermap.org/data/2.5/",
};
