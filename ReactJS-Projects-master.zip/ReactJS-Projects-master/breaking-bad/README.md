# Breaking Bad Characters

Are you a fan of Breaking Bad and Web Development? Then this is the perfect project to work on. The project is built using React and an API from [Breaking Bad API](https://breakingbadapi.com/). To use the project just fork the repository, run `npm i` and then `npm start`.